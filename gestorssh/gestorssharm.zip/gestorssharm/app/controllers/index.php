<?php
header('location: /4g.php');